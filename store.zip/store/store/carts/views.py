# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.shortcuts import render, HttpResponseRedirect
from django.urls import reverse

# Create your views here.
from .models import Cart
from products.models import Product
def view(request):
    cart = Cart.objects.all()[0]
    context = {"cart": cart}
    template = "view.html"
    return render(request, template, context)

def update_cart(request, id):
    cart = Cart.objects.all()[0]
    try:
        product = Product.objects.get(id=id)
    except Product.DoesNotExist:
        pass
    except:
        pass
    if not product in cart.products.all():
        cart.products.remove(product)
    else:
        return HttpResponseRedirect(reverse("cart"))

from django.conf.urls import url
from django.contrib import admin
from.import views
urlpatterns = [
    url('', views.view, name='cart'),
    url('(?P<id>[\w-]+)', views.update_cart, name='update_cart'),
]
# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.db import models
from products.models import Product
# Create your models here.
class Cart(models.Model):
    products = models.ManyToManyField(Product)
    total = models.DecimalField(decimal_places=2, max_digits=4, default=0.00)
    timestamp = models.DateTimeField(auto_now_add=True, auto_now=False)

    def __unicode__(self):
        return "Cart id: %s" % self.id
    #return "Cart id: %s" %(self.id)
from django.conf.urls import url
from django.contrib import admin
from.import views
urlpatterns = [
    url('', views.register, name='register'),
    url('', views.delivery, name='delivery'),
    url('', views.payment, name='payment'),

]
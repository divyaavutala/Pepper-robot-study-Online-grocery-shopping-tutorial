from __future__ import unicode_literals

from django.shortcuts import render
from django.shortcuts import render, HttpResponse
#from django.core.urlresolvers import reverse
from django.urls import reverse

from .models import Other
# Create your views here.

def register(request):
    other = Other.objects.all()[0]
    context = {"other": other}
    template = "register.html"
    return render(request, template, context)

def delivery(request):
    other = Other.objects.all()[0]
    context = {"other": other}
    template = "delivery.html"
    return render(request, template, context)

def payment(request):
    other = Other.objects.all()[0]
    context = {"other": other}
    template = "payment.html"
    return render(request, template, context)


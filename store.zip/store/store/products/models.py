# -*- coding: utf-8 -*-

from django.db import models

# Create your models here.

class Product(models.Model):
    title = models.CharField(max_length=50)
    price = models.DecimalField(decimal_places=True, max_digits=4)
    timestamp = models.DateTimeField(auto_now_add=True, auto_now=False)
    #slug = models.SlugField(unique=True)
    def __unicode__(self):
        return self.title

    def get_price(self):
        return self.price


class ProductImage(models.Model):
    product = models.ForeignKey(Product,on_delete=models.DO_NOTHING,)
    image = models.ImageField(upload_to='products/images/')


    def __unicode__(self):
        return self.product.title
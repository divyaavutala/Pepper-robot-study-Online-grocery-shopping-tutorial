from django.shortcuts import render
from .models import Product
def home(request):
    products = Product.objects.all()
    template = 'home.html'
    context = {'products': products }
    return render(request, template, context)

def all(request):
    products = Product.objects.all()
    context = {'products': products }
    template = 'all.html'
    return render(request, template, context)
